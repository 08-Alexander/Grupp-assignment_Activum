Filer som kommer vara h�r �r dem som tillh�r Customer vyn
      * Mainpage.xaml och Mainpage.xaml.cs
      * InsurancePage.xaml och InsurancePage.xaml.cs
      * CalculatorPage.xaml och CalculatorPage.xaml.cs