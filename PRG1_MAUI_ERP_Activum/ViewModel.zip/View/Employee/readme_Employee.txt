Filer som kommer vara h�r �r dem som tillh�r Employee vyn
      * CustomerPage.xaml och CustomerPage.xaml.cs
      * ToolsPage.xaml och ToolsPage.xaml.cs