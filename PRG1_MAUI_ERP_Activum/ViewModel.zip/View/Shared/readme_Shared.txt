Filer som kommer vara h�r �r dem som tillh�r Shared vyn
      * AboutPage.xaml och AboutPage.xaml.cs
      * SupportPage.xaml och SupportPage.xaml.cs