using System.Windows.Input;
using PRG1_MAUI_ERP_Activum.Services;

namespace PRG1_MAUI_ERP_Activum.ViewModels;

public class LoginViewModel
{
    public string Username { get; set; }
    public string Password { get; set; }

    public ICommand LoginCommand { get; }

    public LoginViewModel()
    {
        LoginCommand = new Command(async () => await OnLogin());
    }

    private async Task OnLogin()
    {
        try
        {
            // ?? Grundl�ggande validering
            if (string.IsNullOrWhiteSpace(Username) ||
                string.IsNullOrWhiteSpace(Password))
            {
                await ErrorService.ShowError(
                    "Anv�ndarnamn och l�senord kr�vs");
                return;
            }

            // ?? F�rs�k logga in via AuthService
            if (!AuthService.TryLogin(Username, Password, out var role))
            {
                await ErrorService.ShowError(
                    "Felaktigt anv�ndarnamn eller l�senord");
                return;
            }

            // ? S�tt global app-state
            AppState.Username = Username;
            AppState.UserRole = role;
            AppState.NotifyStateChanged();

            // ?? Navigera baserat p� roll
            await Shell.Current.GoToAsync(
                role == "Customer"
                    ? "//CustomerHome"
                    : "//EmployeeHome");
        }
        catch (Exception ex)
        {
            await ErrorService.ShowUnexpected(ex);
        }
    }
}
